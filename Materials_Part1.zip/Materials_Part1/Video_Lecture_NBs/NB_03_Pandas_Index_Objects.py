#!/usr/bin/env python
# coding: utf-8

# # Part 1: Pandas - from Zero to Hero

# ## Pandas Index Objects

# ### First Steps

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv", index_col="Athlete")


# In[ ]:


summer.head()


# In[ ]:


summer.tail()


# In[ ]:


summer.info()


# In[ ]:


summer.index


# In[ ]:


type(summer.index)


# In[ ]:


summer.columns


# In[ ]:


type(summer.columns)


# In[ ]:


summer.axes


# In[ ]:


summer.columns[:3]


# In[ ]:


summer.index[0]


# In[ ]:


summer.index[-1]


# In[ ]:


summer.index[100:102]


# In[ ]:


summer.columns.tolist()


# In[ ]:


summer.index.is_unique


# In[ ]:


summer.index.get_loc("DRIVAS, Dimitrios")


# In[ ]:





# ### Creating Index Objects

# In[ ]:


import pandas as pd


# In[ ]:


list_1 = [1,2,3]


# In[ ]:


pd.Index(list_1)


# In[ ]:


list_2 = ["m", "t", "w"]


# In[ ]:


pd.Index(list_2)


# In[ ]:


index_1 = pd.Index(range(1,4))
index_1


# In[ ]:


index_2 = pd.Index(["Mo", "Tue", "Wed"], name = "days")
index_2


# In[ ]:


pd.Series([34,32,21], index = index_1)


# In[ ]:





# ### Changing Row Index Labels

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv", index_col="Athlete")


# In[ ]:


summer.head()


# In[ ]:


summer.index


# In[ ]:


summer.reset_index(drop = False, inplace=True)


# In[ ]:


summer.head()


# In[ ]:


summer.set_index("Year", drop = True, inplace = True)


# In[ ]:


summer.head()


# In[ ]:


summer.index.is_unique


# In[ ]:


#summer.index[0] = 1894


# In[ ]:


#summer.index = "Before 2016"


# In[ ]:


summer.index.size


# In[ ]:


new_index = ["Medal_No{}".format(i) for i in range(1,summer.index.size+1)]
new_index


# In[ ]:


summer.index = new_index


# In[ ]:


summer.head()


# In[ ]:


summer.tail()


# In[ ]:


summer.index.is_unique


# In[ ]:


summer.index.name = "Medal_No"


# In[ ]:


summer.reset_index()


# In[ ]:





# ### Changing Column Labels

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.tail()


# In[ ]:


titanic.columns


# In[ ]:


titanic.columns[0]


# In[ ]:


#titanic.columns[0] = "Alive"


# In[ ]:


titanic.columns = ["Alive", "Class", "Sex", "Age", "SibSp", "ParChi", "Fare", "Emb", "Deck"]


# In[ ]:


titanic.head()


# In[ ]:


titanic.columns.name


# In[ ]:


titanic.columns.name = "Pass_Charact"


# In[ ]:


titanic.head()


# In[ ]:


titanic.index.name = "Passenger_no"


# In[ ]:





# ### Renaming Index & Column Labels

# In[ ]:


import pandas as pd


# In[ ]:


summer= pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer


# In[ ]:


#summer.index[0] = 'HAYOS, Alfred'


# In[ ]:


summer.rename(mapper = {"HAJOS, Alfred":'HAYOS, Alfred'}, axis = "index")


# In[ ]:


summer.rename(index = {"HAJOS, Alfred":'HAYOS, Alfred'}, inplace = True)


# In[ ]:


summer


# In[ ]:


summer.rename(mapper = {"Sex":"Gender", "City":"Host_City"}, axis = "columns")


# In[ ]:


summer.rename(columns = {"Sex":"Gender", "City":"Host_City"}, inplace = True)


# In[ ]:


summer


# In[ ]:




