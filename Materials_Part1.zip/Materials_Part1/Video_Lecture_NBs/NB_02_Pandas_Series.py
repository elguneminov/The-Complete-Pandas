#!/usr/bin/env python
# coding: utf-8

# # Part 1: Pandas - from Zero to Hero

# ## Pandas Series

# ### First Steps with Pandas Series

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic


# In[ ]:


titanic.info()


# In[ ]:


titanic["age"]


# In[ ]:


type(titanic["age"])


# In[ ]:


titanic["age"].equals(titanic.age)


# In[ ]:


age = titanic["age"]


# In[ ]:


age.head(2)


# In[ ]:


age.tail()


# In[ ]:


age.dtype


# In[ ]:


age.shape


# In[ ]:


len(age)


# In[ ]:


age.index


# In[ ]:


age.info()


# In[ ]:


age.to_frame().info()


# In[ ]:





# ###  Analyzing Numerical Series

# In[ ]:


age


# In[ ]:


age.describe()


# In[ ]:


age.count()


# In[ ]:


age.size


# In[ ]:


len(age)


# In[ ]:


age.sum(skipna = False)


# In[ ]:


sum(age)


# In[ ]:


age.mean()


# In[ ]:


age.median()


# In[ ]:


age.std()


# In[ ]:


age.min()


# In[ ]:


age.max()


# In[ ]:


age.unique()


# In[ ]:


len(age.unique())


# In[ ]:


age.nunique(dropna = False)


# In[ ]:


age.value_counts()


# In[ ]:


age.value_counts(sort = True)


# In[ ]:


age.value_counts(sort = False)


# In[ ]:


age.value_counts(dropna = True)


# In[ ]:


age.value_counts(dropna = False)


# In[ ]:


age.value_counts(ascending = False)


# In[ ]:


age.value_counts(ascending = True)


# In[ ]:


age.value_counts(sort = True, dropna = True, ascending = False, normalize = False)


# In[ ]:


age.value_counts(sort = True, dropna = True, ascending = False, normalize = True)


# In[ ]:


30/age.count()


# In[ ]:


age.value_counts(sort = True, dropna = False, ascending = False, normalize = True)


# In[ ]:


30/age.size


# In[ ]:


age.value_counts(sort = True, dropna = True, ascending= False, normalize = False, bins = 5)


# In[ ]:


age.value_counts(sort = True, dropna = True, ascending= False, normalize = True, bins = 10)


# In[ ]:





# ### Analyzing non-numerical Series

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


summer.info()


# In[ ]:


athlete = summer["Athlete"]


# In[ ]:


athlete.head()


# In[ ]:


athlete.tail(5)


# In[ ]:


type(athlete)


# In[ ]:


athlete.dtype


# In[ ]:


athlete.shape


# In[ ]:


athlete.describe()


# In[ ]:


athlete.size


# In[ ]:


athlete.count()


# In[ ]:


athlete.min()


# In[ ]:


athlete.unique()


# In[ ]:


len(athlete.unique())


# In[ ]:


athlete.nunique(dropna= False)


# In[ ]:


athlete.value_counts()


# In[ ]:


athlete.value_counts(sort = True, ascending=True)


# In[ ]:


athlete.value_counts(sort = True, ascending=False, normalize = True).head()


# In[ ]:





# ### Creating Pandas Series (Part 1)

# In[ ]:


import pandas as pd


# #### from DataFrame

# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


summer["Athlete"]


# In[ ]:


summer.Athlete


# In[ ]:


summer.iloc[0]


# #### Importing from CSV

# In[ ]:


pd.read_csv("summer.csv", usecols = ["Athlete"], squeeze = True)


# #### Creating from scratch with pd.Series()

# In[ ]:


pd.Series([10,25,6,36,2])


# In[ ]:


#pd.Series([10,25,6,36,2], index=["Mon","Tue","Wed","Thu", "Fri", "Sat"])


# In[ ]:


pd.Series([10,25,6,36,2], index=["Mon","Tue","Wed","Thu", "Fri"], name = "Sales")


# In[ ]:





# ### Creating Pandas Series (Part 2)

# #### from Numpy Array

# In[ ]:


import pandas as pd
import numpy as np


# In[ ]:


sales = np.array([10,25,6,36,2])
sales


# In[ ]:


pd.Series(sales)


# #### from List

# In[ ]:


sales = [10,25,6,36,2]


# In[ ]:


pd.Series(sales)


# #### from Dictionary

# In[ ]:


dic = {"Mon":10, "Tue":25, "Wed":6, "Thu": 36, "Fri": 2}
dic


# In[ ]:


sales = pd.Series(dic)


# In[ ]:


sales


# In[ ]:


pd.Series(dic, index = ["Fri", "Sat", "Sun", "Mon", "Tue", "Wed"])


# In[ ]:


pd.Series(dic, index = [1,2,3,4,5])


# In[ ]:





# ### Indexing and Slicing

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.tail()


# In[ ]:


age = titanic.age


# In[ ]:


age.head()


# In[ ]:


age.tail()


# In[ ]:


age.index


# In[ ]:


age[0]


# In[ ]:


age[2]


# In[ ]:


age.iloc[-1]


# In[ ]:


age[890]


# In[ ]:


age[[3,4]]


# In[ ]:


age.loc[:3]


# In[ ]:


summer = pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer.head()


# In[ ]:


event = summer.Event


# In[ ]:


event.head()


# In[ ]:


event.tail()


# In[ ]:


event.index


# In[ ]:


event[0]


# In[ ]:


event[1]


# In[ ]:


event.iloc[-1]


# In[ ]:


event.iloc[:3]


# In[ ]:


event["DRIVAS, Dimitrios"]


# In[ ]:


event[:"DRIVAS, Dimitrios"]


# In[ ]:


event.loc["PHELPS, Michael"]


# In[ ]:


event.loc["PHELPS, Michael"].equals(event["PHELPS, Michael"])


# In[ ]:


#event[:"PHELPS, Michael"]


# In[ ]:


event.loc[["PHELPS, Michael", "LEWIS, Carl"]]


# In[ ]:


#event[["PHELPS, Michael", "DUCK, Donald"]]


# In[ ]:





# ### Sorting and introduction to the  inplace-parameter

# In[ ]:


import pandas as pd


# In[ ]:


dic = {1:10, 3:25, 2:6, 4:36, 5:2, 6:0, 7:None}
dic


# In[ ]:


sales = pd.Series(dic)
sales


# In[ ]:


sales.sort_index()


# In[ ]:


sales.sort_index(ascending = True, inplace= True)


# In[ ]:


sales


# In[ ]:


sales.sort_values(inplace=False)


# In[ ]:


sales


# In[ ]:


sales.sort_values(ascending=False, na_position="last", inplace= True)


# In[ ]:


sales


# In[ ]:


dic = {"Mon":10, "Tue":25, "Wed":6, "Thu": 36, "Fri": 2}
dic


# In[ ]:


sales = pd.Series(dic)


# In[ ]:


sales


# In[ ]:


sales.sort_index(ascending=False)


# In[ ]:





# ### nlargest() and nsmallest()

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


age = titanic.age


# In[ ]:


age.head()


# In[ ]:


age.sort_values(ascending=False).head(3)


# In[ ]:


age.sort_values(ascending=True).iloc[:3]


# In[ ]:


age.nlargest(n = 3).index[0]


# In[ ]:


age.nsmallest(n = 3).index[0]


# In[ ]:





# ### idxmin() and idxmax()

# In[ ]:


titanic.head()


# In[ ]:


titanic.age.idxmax()


# In[ ]:


titanic.age.idxmin()


# In[ ]:


titanic.loc[630]


# In[ ]:


titanic.loc[titanic.age.idxmin()]


# In[ ]:


dic = {"Mon":10,"Tue":25, "Wed":6, "Thu":36, "Fri":2, "Sat":0, "Sun":None}
dic


# In[ ]:


sales = pd.Series(dic)
sales


# In[ ]:


sales.sort_values(ascending=True).index[0]


# In[ ]:


sales.idxmin()


# In[ ]:


sales.sort_values(ascending=False).index[0]


# In[ ]:


sales.idxmax()


# In[ ]:





# ### Manipulating Series

# In[ ]:


import pandas as pd


# In[ ]:


sales = pd.Series([10,25,6,36,2,0,None,5], index = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "Mon"])
sales


# In[ ]:


sales["Sun"] = 0


# In[ ]:


sales


# In[ ]:


sales.iloc[3] = 30


# In[ ]:


sales


# In[ ]:


(sales/1.1).round(2)


# In[ ]:


sales_EUR = (sales/1.1).round(2)
sales_EUR


# In[ ]:


sales = (sales/1.1).round(2)


# In[ ]:


sales


# In[ ]:


sales["Mon"] = 0


# In[ ]:


sales


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


age = titanic["age"]


# In[ ]:


age.head()


# In[ ]:


age.tail()


# In[ ]:


age.iloc[1] = 30 


# In[ ]:


age.head()


# In[ ]:


titanic.head()


# In[ ]:




