#!/usr/bin/env python
# coding: utf-8

# # Part 1: Pandas - from Zero to Hero

# ## Manipulating Values in a DataFrame

# ### Best Practise (how you should do it)

# In[1]:


import pandas as pd


# In[2]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# #### Changing a single Value (Option 1 with loc)

# In[ ]:


titanic.loc[1, "age"] = 40


# In[ ]:


titanic.head()


# #### Changing a single Value (Option 2 with iloc) 

# In[ ]:


titanic.iloc[1, 3] = 41


# In[ ]:


titanic.head()


# #### Changing multiple values in a column (Option 1 with loc)

# In[ ]:


titanic.loc[1:3, "age"] = 42


# In[ ]:


titanic.head()


# #### Changing multiple values in a column (Option 2 with iloc)

# In[ ]:


titanic.iloc[1:4, 3] = [43, 44, 45]


# In[ ]:


titanic.head()


# #### Changing multiple values in a column (Option 3 with boolean indexing)

# In[ ]:


index_babies = titanic.loc[titanic.age < 1, "age"].index


# In[ ]:


titanic.loc[titanic.age < 1, "age"] = 1


# In[ ]:


titanic.loc[index_babies]


# #### Changing multiple values in a row 

# In[ ]:


titanic.head()


# In[ ]:


titanic.loc[0,"survived":"sex"] =[1, 1, "female"]


# In[ ]:


titanic.head()


# #### Changing multiple values in multiple rows/columns

# In[ ]:


titanic.replace(0, "Zero")


# In[ ]:





# ### How you should NOT do it (Part 1)

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


age = titanic.age


# In[ ]:


age.head()


# In[ ]:


age[1] = 40


# In[ ]:


age.head()


# In[ ]:


titanic.head()


# In[ ]:


titanic.age[1] = 41 #This is Chained Indexing!!!


# In[ ]:


titanic.loc[1, "age"] = 42 #This is NOT Chained Indexing and the idiomatic/best way to do it!!!


# ![image.png](attachment:image.png)

# In[ ]:





# In[ ]:


slice1 = titanic[["sex", "age"]]
slice1.head()


# In[ ]:


slice1.iloc[1,1] = 43


# In[ ]:


slice1


# In[ ]:


titanic.head()


# ![image.png](attachment:image.png)

# In[ ]:





# In[ ]:


slice2 = titanic.loc[:, ["sex","age"]]
slice2


# In[ ]:


slice2.iloc[1,1] = 44


# In[ ]:


slice2.head()


# In[ ]:


titanic.head()


# ![image.png](attachment:image.png)

# In[ ]:





# ### How you should NOT do it (Part 2)

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


index_babies = titanic[titanic.age < 1].index


# In[ ]:


titanic[titanic.age < 1]["age"] = 1


# In[ ]:


titanic.loc[index_babies,:]


# ![image.png](attachment:image.png)

# In[ ]:





# In[ ]:


titanic["age"][titanic.age < 1] = 1


# In[ ]:


titanic.loc[index_babies]


# ![image.png](attachment:image.png)

# In[ ]:





# In[ ]:


titanic[["sex", "age"]][titanic.age == 1]["age"] = 0


# In[ ]:


titanic.loc[index_babies]


# ![image.png](attachment:image.png)

# #### SettingWithCopyWarning: You assigned new values with Chained Indexing. It is not clear, whether you changed the original DataFrame and whether this was your intention at all. So, please check!!!

# ![image.png](attachment:image.png)

# ### View vs. Copy

# #### Slicing a DataFrame / creating a view on the original DataFrame

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


age = titanic.age


# In[ ]:


age.head()


# In[ ]:


age._is_view


# In[ ]:


age._is_copy is None


# In[ ]:


age[1] = 40


# In[ ]:


age.head()


# In[ ]:


titanic.head()


# #### Slicing a DataFrame / creating a copy of the original DataFrame

# In[ ]:


df_baby = titanic[titanic.age < 1]


# In[ ]:


df_baby._is_view


# In[ ]:


df_baby._is_copy is None


# In[ ]:


df_baby._is_copy()


# In[ ]:


df_baby.age = 1


# In[ ]:


df_baby


# In[ ]:


titanic.loc[index_babies]


# In[ ]:





# ## If you want to work with and manipulate the whole DataFrame...

# ## ... avoid chained Indexing!!! 

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.iloc[1, 3] = 40


# In[ ]:


titanic.head()


# In[ ]:


index_babies = titanic.loc[titanic.age < 1, "age"].index


# In[ ]:


titanic.loc[titanic.age < 1, "age"] = 1


# In[ ]:


titanic.loc[index_babies]


# ## If you want to work with and manipulate a Slice of a DataFrame...

# ## ...avoid chained Indexing ...and make a copy with .copy()

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


age = titanic.age.copy()


# In[ ]:


age.head()


# In[ ]:


age[1] = 40


# In[ ]:


age.head()


# In[ ]:


titanic.head()


# In[ ]:


baby_ages = titanic.loc[titanic.age < 1, ["age", "sex"]].copy()


# In[ ]:


baby_ages


# In[ ]:


baby_ages["age"] = 1


# In[ ]:


baby_ages


# In[ ]:


titanic.loc[index_babies]


# ![image.png](attachment:image.png)

# In[ ]:




