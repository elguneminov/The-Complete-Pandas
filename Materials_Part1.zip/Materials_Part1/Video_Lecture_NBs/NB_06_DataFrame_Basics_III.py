#!/usr/bin/env python
# coding: utf-8

# # Part 1: Pandas - from Zero to Hero

# ## DataFrame Basics III

# ### Sorting DataFrames (Version 1.0 Update)

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic


# In[ ]:


titanic.age.sort_values()


# In[ ]:


titanic.sort_values(by = "age")


# In[ ]:


titanic


# In[ ]:


titanic.sort_values(by = "age", ascending = False, inplace = True)


# In[ ]:


titanic


# In[ ]:


titanic.sort_values(by = ["pclass", "sex", "age"], ascending = [True, True, False], inplace= True)


# In[ ]:


pd.options.display.max_rows = 900


# In[ ]:


titanic


# In[ ]:


titanic.sort_index(ascending = True, inplace = True)


# In[ ]:


titanic


# In[ ]:


titanic.sort_values(by = "age").reset_index(drop = True)


# In[ ]:


titanic.sort_values(by = "age", ignore_index = True)


# In[ ]:





# ### Ranking DataFrames with rank()

# In[ ]:


import pandas as pd


# In[ ]:


sales = pd.Series([15, 32, 45, 21, 55, 15, 0],  index = ["Mo", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])


# In[ ]:


sales = pd.Series([15, 32, 45, 15, 55, 15, 0],  index = ["Mo", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])


# In[ ]:


sales


# In[ ]:


sales.sort_values(ascending = False)


# In[ ]:


sales.rank(ascending=False, method = "min").sort_values(ascending = True)


# In[ ]:


sales.rank(ascending=False, method = "min", pct=True).sort_values()


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.fare.rank(ascending = False)


# In[ ]:


titanic["fare_rank"] = titanic.fare.rank(ascending = False, method="min")


# In[ ]:


titanic.head()


# In[ ]:


titanic.sort_values("fare", ascending= False)


# In[ ]:


titanic.drop(columns = "fare_rank", inplace= True)


# In[ ]:





# ### nunique(), nlargest() and nsmallest() with DataFrames

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.tail()


# In[ ]:


titanic.age.unique()


# In[ ]:


titanic.nunique(axis = 1, dropna=False)


# In[ ]:


titanic.nunique(dropna = False)


# In[ ]:


titanic.nlargest(n = 5, columns = "fare")


# In[ ]:


titanic.sort_values("fare", ascending = False).head(5)


# In[ ]:


titanic.nsmallest(n = 1, columns = "age")


# In[ ]:


titanic.loc[titanic.age.idxmin()]


# In[ ]:





# ### Summary Statistics and Accumulations

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.describe()


# In[ ]:


titanic.count(axis = "columns")


# In[ ]:


titanic.count(axis = 1)


# In[ ]:


titanic.mean(axis = 1)


# In[ ]:


titanic.sum(axis = 0)


# In[ ]:


titanic.head()


# In[ ]:


titanic.fare.cumsum(axis = 0)


# In[ ]:


titanic.corr()


# In[ ]:


titanic.survived.corr(titanic.pclass)


# In[ ]:





# ### The agg() method

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.describe()


# In[ ]:


titanic.mean()


# In[ ]:


titanic.agg("mean")


# In[ ]:


titanic.agg(["mean", "std"])


# In[ ]:


titanic.agg(["mean", "std", "min", "max", "median"])


# In[ ]:


titanic.agg({"survived": "mean", "age":["min", "max"]})


# In[ ]:





# ### apply(), map() and applymap()

# In[ ]:


import pandas as pd


# In[ ]:


sales = pd.read_csv("sales.csv", index_col = 0)


# In[ ]:


sales


# In[ ]:


sales.info()


# In[ ]:


sales.min(axis = 0)


# In[ ]:


sales.min(axis = 1)


# In[ ]:


def range(series):
    return series.max() - series.min()


# In[ ]:


sales.apply(lambda x: x.max() - x.min(), axis = 0)


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


summer.Athlete.apply(lambda x: x[0])


# In[ ]:


summer.Athlete.map(lambda x: x[0])


# In[ ]:


summer.iloc[:,1:3].applymap(lambda x: x[0])


# In[ ]:


sales.applymap(lambda x: 0.4*x-5)


# In[ ]:


sales*0.4-5


# In[ ]:





# ### Hierarchical Indexing (MultiIndex) Intro

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic


# In[ ]:


titanic = titanic.iloc[:50, :]


# In[ ]:


titanic.set_index(["pclass", "sex"], inplace = True)


# In[ ]:


titanic


# In[ ]:


titanic.sort_index(ascending = [True, True], inplace = True )


# In[ ]:


titanic


# In[ ]:


titanic.swaplevel()


# In[ ]:


titanic


# In[ ]:


titanic.reset_index(inplace = True)


# In[ ]:


titanic


# In[ ]:





# ### Hierarchical Indexing (MultiIndex) Part 2

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic = titanic.iloc[:50,]


# In[ ]:


titanic


# In[ ]:


titanic = titanic.set_index(["pclass", "sex"]).sort_index(ascending = True)


# In[ ]:


titanic


# In[ ]:


titanic.loc[1]


# In[ ]:


titanic.loc[[1,2]]


# In[ ]:


titanic.loc[:2]


# In[ ]:


titanic.loc[1, "female"]


# In[ ]:


#titanic.loc[1, "female", "age"]


# In[ ]:


titanic.loc[(1,"female")]


# In[ ]:


titanic.loc[(1,"female"), "age"]


# In[ ]:


titanic.loc[([1,2],"female"), ["age", "fare"]]


# In[ ]:


titanic.loc[([1, 2],"female"), :]


# In[ ]:


titanic


# In[ ]:


titanic.loc[(slice(1), slice("female")), :]


# In[ ]:





# ### String Operations Intro / Refresher

# In[ ]:


"Hello World"


# In[ ]:


type("Hello World")


# In[ ]:


hello = "Hello World"
hello


# In[ ]:


len(hello)


# In[ ]:


hello.lower()


# In[ ]:


hello.upper()


# In[ ]:


hello.title()


# In[ ]:


hello.split(" ")


# In[ ]:


hello.replace("Hello", "Hi")


# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


names = summer.loc[:9, "Athlete"].copy()


# In[ ]:


names


# In[ ]:


names.dtypes


# In[ ]:


names[0]


# In[ ]:


type(names[0])


# In[ ]:


names.str.lower()


# In[ ]:





# ### String Operations in Pandas

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


names = summer.loc[:9, "Athlete"].copy()


# In[ ]:


names


# In[ ]:


names.str.lower()


# In[ ]:


names.str.title()


# In[ ]:


summer.Event.str.split(" ", n = 2, expand= True)


# In[ ]:


summer[summer.Event.str.contains("100M")]


# In[ ]:




