#!/usr/bin/env python
# coding: utf-8

# # Part 1: Pandas - from Zero to Hero

# ## DataFrame Basics II

# ### Filtering DataFrames with one Condition

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head(10)


# In[ ]:


titanic.sex.head(10)


# In[ ]:


titanic.sex == "male"


# In[ ]:


titanic[titanic.sex == "male"]["fare"]


# In[ ]:


titanic.loc[titanic.sex == "male", "fare"]


# In[ ]:


mask1 = titanic.sex == "male"
mask1


# In[ ]:


titanic_male = titanic.loc[mask1]


# In[ ]:


titanic_male.head()


# In[ ]:


titanic.dtypes# == object


# In[ ]:


mask2 = titanic.dtypes == object
mask2


# In[ ]:


titanic.loc[:, ~mask2]


# In[ ]:


titanic.loc[mask1, ~mask2]


# In[ ]:





# ### Filtering DataFrames with many Conditions (AND)

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head(10)


# In[ ]:


mask1 = titanic.sex == "male"
mask1.head()


# In[ ]:


mask2 = titanic.age > 14
mask2.head()


# In[ ]:


(mask1 & mask2).head()


# In[ ]:


male_adult = titanic.loc[mask1 & mask2, ["survived", "pclass", "sex", "age"]]
male_adult.head(20)


# In[ ]:


male_adult.info()


# In[ ]:


male_adult.describe()


# In[ ]:


titanic.describe()


# In[ ]:





# ### Filtering DataFrames with many Conditions (OR)

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


mask1 = titanic.sex == "female"
mask1.head(20)


# In[ ]:


mask2 = titanic.age < 14
mask2.head(20)


# In[ ]:


(mask1 | mask2).head(11)


# In[ ]:


titanic.loc[mask1 | mask2]


# In[ ]:


wom_or_chi = titanic.loc[mask1 | mask2, ["survived", "pclass", "sex", "age"]]


# In[ ]:


wom_or_chi.head()


# In[ ]:


wom_or_chi.info()


# In[ ]:


wom_or_chi.describe()


# In[ ]:


titanic.describe()


# In[ ]:





# ### Advanced Filtering with between(), isin() and ~

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


og_1988 = summer.loc[summer.Year == 1988]


# In[ ]:


og_1988.head()


# In[ ]:


og_1988.tail()


# In[ ]:


og_1988.info()


# In[ ]:


og_since1992 = summer.loc[summer.Year >= 1992]


# In[ ]:


og_since1992.head()


# In[ ]:


og_since1992.tail()


# In[ ]:


summer.Year.between(1960, 1969).head()


# In[ ]:


og_60s = summer.loc[summer.Year.between(1960, 1969, inclusive=True)]


# In[ ]:


og_60s.head()


# In[ ]:


og_60s.tail()


# In[ ]:


my_favourite_games = [1972, 1996]


# In[ ]:


summer.Year.isin(my_favourite_games).head()


# In[ ]:


og_72_96 = summer.loc[summer.Year.isin(my_favourite_games)]


# In[ ]:


og_72_96.head()


# In[ ]:


og_72_96.tail()


# In[ ]:


og_not_72_96 = summer.loc[~summer.Year.isin(my_favourite_games)]


# In[ ]:


og_not_72_96.head()


# In[ ]:


og_not_72_96.Year.unique()


# In[ ]:





# ### any() and all()

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.sex == "male"


# In[ ]:


(titanic.sex == "male").any()


# In[ ]:


(titanic.sex == "male").all()


# In[ ]:


(titanic.age == 80.0).any()


# In[ ]:


pd.Series([-1, 0.5 , 1, -0.1, 0]).any()


# In[ ]:


titanic.fare.all()


# In[ ]:





# ### Removing Columns

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


summer.drop(columns = "Sport")


# In[ ]:


summer.head()


# In[ ]:


summer.drop(columns = ["Sport", "Discipline"], inplace=True)


# In[ ]:


summer.drop(labels = "Event", axis = "columns", inplace= True)


# In[ ]:


#del summer["Event"]


# In[ ]:


summer.head()


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


summer = summer.loc[:,["Year", "City", "Athlete", "Country", "Gender", "Medal"]]


# In[ ]:


summer.head()


# In[ ]:





# ### Removing Rows

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer.head(10)


# In[ ]:


summer.drop(index = "HAJOS, Alfred")


# In[ ]:


summer.drop(index = ["HAJOS, Alfred","HERSCHMANN, Otto"], inplace = True)


# In[ ]:


summer.head()


# In[ ]:


summer.drop(labels = "DRIVAS, Dimitrios", axis = 0,  inplace = True)


# In[ ]:


summer.head()


# In[ ]:


summer = summer.loc[summer.Year == 1996]


# In[ ]:


summer.head()


# In[ ]:


summer = pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer.head()


# In[ ]:


mask1 = summer.Year == 1996
mask2 = summer.Sport == "Aquatics"


# In[ ]:


summer = summer.loc[~(mask1 | mask2)]


# In[ ]:


summer.head()


# In[ ]:


(summer.Year == 1996).value_counts()


# In[ ]:


1996 in summer.Year.values


# In[ ]:


summer.Sport.isin(["Aquatics"]).any()


# In[ ]:


(summer.Sport == "Aquatics").any()


# In[ ]:





# ### Adding new Columns to a DataFrame

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic["Zeros"] = "Zero"


# In[ ]:


titanic.head()


# In[ ]:


titanic.Ones = 1


# In[ ]:


titanic.head()


# In[ ]:


titanic.Ones


# In[ ]:





# ### Creating Columns based on other Columns

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


1912 - titanic.age


# In[ ]:


titanic["YoB"] = 1912 - titanic.age


# In[ ]:


titanic.head()


# In[ ]:


titanic.sibsp + titanic.parch


# In[ ]:


titanic["relatives"] = titanic.sibsp + titanic.parch


# In[ ]:


titanic.head()


# In[ ]:


titanic.drop(columns = ["sibsp", "parch"], inplace = True)


# In[ ]:


titanic.head()


# In[ ]:


inflation_factor = 10


# In[ ]:


titanic.fare*10


# In[ ]:


titanic.fare = titanic.fare*10


# In[ ]:


titanic.head()


# In[ ]:





# ### Adding Columns with insert()

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic["Test"] = "Test"


# In[ ]:


titanic.head()


# In[ ]:


relatives = titanic.sibsp + titanic.parch
relatives.head()


# In[ ]:


titanic.insert(loc = 6, column = "relatives", value = relatives)


# In[ ]:


titanic.head()


# In[ ]:





# ### Creating DataFrames from Scratch with pd.DataFrame()

# In[ ]:


import pandas as pd


# #### Having Columns in place

# In[ ]:


player = ["Lionel Messi", "Cristiano Ronaldo", "Neymar Junior", "Kylian Mbappe", "Manuel Neuer"]


# In[ ]:


nationality = ["Argentina", "Portugal", "Brasil", "France", "Germany"]


# In[ ]:


club = ["FC Barcelona", "Juventus FC", "Paris SG", "Paris SG", "FC Bayern" ]


# In[ ]:


world_champion = [False, False, False, True, True]


# In[ ]:


height = [1.70, 1.87, 1.75, 1.78, 1.93]


# In[ ]:


goals = [45, 44, 28, 21, 0]


# In[ ]:


dic = {"Player":player, "Nationality":nationality, "Club":club, 
        "World_Champion":world_champion, "Height":height, "Goals_2018":goals
       }


# In[ ]:


dic


# In[ ]:


df = pd.DataFrame(data = dic)


# In[ ]:


df


# In[ ]:


players = df.set_index("Player")


# In[ ]:


players


# #### Having Rows in place

# In[ ]:


list(zip(nationality, club, world_champion, height, goals))


# In[ ]:


zipped = list(zip(nationality, club, world_champion, height, goals))


# In[ ]:


messi, ronaldo, neymar, mbappe, neuer = zipped


# In[ ]:


messi


# In[ ]:


ronaldo


# In[ ]:


df = pd.DataFrame(data = [messi, ronaldo, neymar, mbappe, neuer],
             index = ["Lionel Messi", "Cristiano Ronaldo", "Neymar Junior", "Kylian Mbappe", "Manuel Neuer"],
             columns = ["Nationality", "Club", "World_Champion", "Height", "Goals_2018"]
            )


# In[ ]:


df


# In[ ]:


df2 = pd.Series(index = player, data = nationality, name = "Nationality").to_frame()


# In[ ]:


df2


# In[ ]:


df2["Club"] = club


# In[ ]:


df2


# In[ ]:





# ### Adding new Rows (hands-on approach)

# #### Adding one Row

# In[ ]:


players


# In[ ]:


players.reset_index(inplace= True)


# In[ ]:


players


# In[ ]:


players.loc[5, :] = ["Sergio Ramos", "Spain", "Real Madrid", True, 1.84 ,5]


# In[ ]:


players


# #### Adding many Rows

# In[ ]:


new = pd.DataFrame(
    data = [["Mohamed Salah", "Egypt", "FC Liverpool", False, 1.75, 44],
            ["Luis Suarez", "Uruguay", "FC Barcelona", False, 1.82, 31]],
    columns = players.columns
)


# In[ ]:


new


# In[ ]:


players = players.append(new, ignore_index= True)


# In[ ]:


players


# In[ ]:




