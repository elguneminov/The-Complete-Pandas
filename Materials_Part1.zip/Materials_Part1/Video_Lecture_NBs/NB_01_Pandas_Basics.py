#!/usr/bin/env python
# coding: utf-8

# # Part 1: Pandas - from Zero to Hero

# ## First Steps with Pandas

# ### Creating your very first Pandas DataFrame (from csv)

# In[ ]:


import pandas as pd


# In[ ]:


pd.read_csv("titanic.csv")


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic


# In[ ]:





# ### Pandas Display Options and the methods head() & tail()

# In[ ]:


titanic


# In[ ]:


print(titanic)


# In[ ]:


pd.options.display.max_rows


# In[ ]:


pd.options.display.min_rows


# In[ ]:


titanic


# In[ ]:


titanic.head()


# In[ ]:


titanic.head(20)


# In[ ]:


titanic.tail()


# In[ ]:


titanic.tail(2)


# In[ ]:





# ### First Data Inspection

# In[ ]:


titanic


# In[ ]:


titanic.info()


# In[ ]:


titanic.describe()


# In[ ]:


titanic.describe(include = "O")


# In[ ]:





# ### Python Built-in Functions & DataFrame Attributes and Methods

# In[ ]:


titanic


# #### DataFrames and Python Built-in Functions

# In[ ]:


type(titanic)


# In[ ]:


len(titanic)


# In[ ]:


round(titanic, 0)


# In[ ]:


#int(titanic)


# In[ ]:


min(titanic)


# #### DataFrame Attributes

# In[ ]:


titanic.shape


# In[ ]:


titanic.size


# In[ ]:


titanic.index


# In[ ]:


titanic.columns


# #### DataFrame Methods

# In[ ]:


titanic.head(n = 2)


# In[ ]:


titanic.info()


# In[ ]:


titanic.min()


# #### Method Chaining

# In[ ]:


titanic.mean().sort_values().head(2)


# In[ ]:





# ### Selecting Columns

# In[ ]:


titanic


# In[ ]:


titanic["age"]


# In[ ]:


type(titanic["age"])


# In[ ]:


#titanic["age", "sex"]


# In[ ]:


titanic[["age", "sex"]]


# In[ ]:


type(titanic[["age", "sex"]])


# In[ ]:


titanic[["sex", "age"]]


# In[ ]:


titanic[["sex", "age", "fare"]]


# In[ ]:


type(titanic[["age"]])


# In[ ]:





# ### Selecting one Column with "dot notation"

# In[ ]:


titanic.age


# In[ ]:


titanic.age.equals(titanic["age"])


# In[ ]:


titanic.embarked


# In[ ]:





# ### Position-based Indexing and Slicing with iloc[]

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer


# In[ ]:


summer.info()


# #### Selecting Rows with iloc[]

# In[ ]:


summer.iloc[0]


# In[ ]:


type(summer.iloc[0])


# In[ ]:


summer.iloc[1]


# In[ ]:


summer.iloc[-1]


# In[ ]:


summer.iloc[[1, 2, 3]]


# In[ ]:


summer.iloc[1:4]


# In[ ]:


summer.iloc[:5]


# In[ ]:


summer.iloc[-5:]


# In[ ]:


summer.iloc[:]


# In[ ]:


summer.iloc[[2, 45, 5467]]


# #### Indexing/Slicing Rows and Columns with iloc[]

# In[ ]:


summer.head(10)


# In[ ]:


summer.iloc[0, 4]


# In[ ]:


summer.iloc[0, :3]


# In[ ]:


summer.iloc[0, [0, 2, 5, 7]]


# In[ ]:


summer.iloc[34:39, [0, 2, 5, 7]]


# #### Selecting Columns with iloc[]

# In[ ]:


summer.iloc[:, 4].equals(summer.Country)


# In[ ]:


summer["Country"]


# In[ ]:





# ### Label-based Indexing and Slicing with loc[] 

# In[ ]:


summer


# #### Selecting Rows with loc[]

# In[ ]:


summer.iloc[2]


# In[ ]:


summer.loc["DRIVAS, Dimitrios"]


# In[ ]:


summer.loc["PHELPS, Michael"]


# In[ ]:





# #### Indexing/Slicing Rows and Columns with loc[]

# In[ ]:


summer.loc["PHELPS, Michael", "Medal"]


# In[ ]:


summer.loc["PHELPS, Michael", ["Medal", "Event"]]


# In[ ]:


summer.loc[["PHELPS, Michael", "LEWIS, Carl"], ["Medal", "Event"]]


# In[ ]:


summer.loc[:, ["Medal", "Event"]]


# In[ ]:


summer.head(10)


# In[ ]:


summer.loc[:"CHASAPIS, Spiridon"]


# In[ ]:


#summer.loc[:"PHELPS, Michael"]


# In[ ]:


#summer.loc["PHELPS, Michael":]


# In[ ]:


summer.head(20)


# In[ ]:


summer.loc["DRIVAS, Dimitrios":"BLAKE, Arthur", "City":"Discipline"]


# In[ ]:


#summer.loc[["PHELPS, Michael", "DUCK, Donald"]]


# In[ ]:


#summer.loc["PHELPS, Michael", ["Year", "Age"]]


# In[ ]:





# ### Indexing and Slicing with reindex()

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer


# In[ ]:


#summer.loc[[0, 5, 30000, 40000], ["Athlete", "Medal"]]


# In[ ]:


summer.reindex(index = [0, 5, 30000, 40000], columns =  ["Athlete", "Medal", "Age"])


# In[ ]:


summer = pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer


# In[ ]:


summer.reindex(columns = ["Medal", "Age"])


# In[ ]:


#summer.reindex(index = ["PHELPS, Michael"], columns = ["Medal", "Age"])


# In[ ]:





# ### Summary and Outlook

# #### Importing from CSV and first Inspection

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer


# In[ ]:


summer.info()


# #### Selecting one Column

# In[ ]:


summer.Medal


# In[ ]:


summer["Medal"]


# #### Selecting multiple Columns

# In[ ]:


summer[["Year", "Medal"]]


# In[ ]:


summer.loc[:, ["Year", "Medal"]]


# #### Selecting positional rows

# In[ ]:


summer.iloc[10:21]


# #### Selecting labeled rows

# In[ ]:


summer.loc["LEWIS, Carl"]


# #### Putting it all together

# In[ ]:


summer[["Year", "Event", "Medal"]].loc["LEWIS, Carl"]


# In[ ]:


summer.loc["LEWIS, Carl"][["Year", "Event", "Medal"]]


# In[ ]:


summer.loc["LEWIS, Carl", ["Year", "Event", "Medal"]]


# #### Outlook Pandas Objects

# In[ ]:


summer


# In[ ]:


type(summer)


# In[ ]:


summer["Year"]


# In[ ]:


type(summer["Year"])


# In[ ]:


summer.columns


# In[ ]:


type(summer.columns)


# In[ ]:


summer.index


# In[ ]:


type(summer.index)


# In[ ]:





# ### Advanced Indexing and Slicing (optional)

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer


# __Case 1: Getting the first 5 rows and rows 354 and 765__

# In[ ]:


rows = list(range(5)) + [354, 765]
rows


# In[ ]:


summer.iloc[rows]


# __Case 2: Getting the first three columns and the columns "Gender" and "Event"__

# In[ ]:


summer.columns[:3].to_list() + ["Gender", "Event"]


# In[ ]:


col = summer.columns[:3].to_list() + ["Gender", "Event"]
col


# In[ ]:


summer.loc[:, col]


# __Case 3: Combining Position- and label-based Indexing__: Rows at Positions 200 and 300 and columns "Athlete" and "Medal"

# In[ ]:


summer


# In[ ]:


summer.loc[[200, 300], ["Athlete", "Medal"]]


# __Case 4: Combining Position- and label-based Indexing__: Rows "PHELPS Michael" and positional columns 4 and 6

# In[ ]:


summer = pd.read_csv("summer.csv", index_col = "Athlete")


# In[ ]:


summer


# In[ ]:


col = summer.columns[[4, 6]]
col


# In[ ]:


summer.loc["PHELPS, Michael", col]


# In[ ]:


#summer.ix["PHELPS, Michael", [4, 6]]


# In[ ]:




