#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## Pandas Series
# 

# ### Exercise 3: Analyzing Columns / Pandas Series

# In[ ]:


#run the cell!
import pandas as pd


# In[ ]:


#run the cell!
cars = pd.read_csv("cars.csv")


# In[ ]:


#run the cell!
cars


# In[ ]:


#run the cell!
cars.info()


# 18. Select the numerical column __"mpg"__, create a __copy__ and __save__ the column/Pandas Series in the variable __mpg__! __Fill in the gaps__!

# In[ ]:


mpg = cars.mpg.copy()


# In[ ]:


#run the cell!
mpg


# 19. Get some __summary statistics__ on the Series __mpg__! What is the __mpg__ of the __least fuel efficient__ car?

# In[ ]:


mpg.describe()


# The mpg of the least fuel efficient car is ... 9.0 miles per gallon!

# 20. Get the __maximum Value__ in the Series __mpg__ by explicitly calling the ... method! The __most fuel efficient__ car has a __mpg__ of...?

# In[ ]:


mpg.max()


# The most fuel efficient car has a mpg of... 46.6!

# 21. Get the Frequency/__Counts__ of all unique __values__ in the Series __mpg__! What is the __most frequent__ value?

# In[ ]:


mpg.value_counts()


# The most frequent value is ... 13.0!

# 22. Get the __relative frequencies__ in the Series __mpg__! What is the __relative frequency__ of the __most frequent value__?

# In[ ]:


mpg.value_counts(normalize = True)


# The relative frequency of 13.0 is ... 0.050251!

# 23. __Sort__ the Series __mpg__ from __low to high__! What is the __second lowest__ value?

# In[ ]:


mpg.sort_values()


# The second lowest value is ... 10.0!

# 24. __Sort__ the Series __mpg__ from __high to low__ and __save the changes__ by setting the __inplace__ parameter to __True__!  <br>
# __Fill in the gaps!__

# In[ ]:


mpg.sort_values(ascending = False, inplace = True)


# Inspect the __first 5 elements__ of mpg! What is the __second highest__ value?

# In[ ]:


#run the cell!
mpg.head()


# The second highest value is ... 44.6!

# 25. __Sort__ the Series __mpg__ by the __Index__ and __save__ the changes!

# In[ ]:


mpg.sort_index(inplace = True)


# In[ ]:


#run the cell!
mpg


# __Miles per Gallon__ (mpg) can be transformed into __Liter per 100 Kilometer__ with the following formula:<br>
# __Liter per 100 Kilometer = 235.21 / mpg__<br><br>
# 26. Create a new Pandas Series __l_per_100__ by applying the above formula! __Round__ the results to __2 decimals__! __Fill in the gaps__!

# In[ ]:


l_per_100 = (235.21/mpg).round(2)


# Run and Inspect. What is the __very first__ element?

# In[ ]:


#run the cell!
l_per_100


# The first element is ... 13.07!

# 27. Get some __summary statistics__ on the Series __l_per_100__! What is the __average__ value?

# In[ ]:


l_per_100.describe()


# The average value is approx. ... 11.21!

# 28. Select the non-numerical column __"origin"__, create a __copy__ and __save__ the column/Pandas Series in the variable __origin__! 

# In[ ]:


origin = cars.origin.copy()


# Inspect! The first 5 elements are all...?

# In[ ]:


#run the cell!
origin


# The first 5 elements are all ... usa!

# 29. Call the __describe()__ method on the non-numerical Series __"origin"__! What is the __most frequent__ value?

# In[ ]:


origin.describe()


# The most frequent value is ... usa!

# 30. Get all __unique values__ in the Series __origin__! Apart from the value usa, there are also the values...?

# In[ ]:


origin.unique()


# ... japan and europe!

# 31. Last but not least, __count the frequencies__ in the Series __origin__! How often does the value __europe__ appear?

# In[ ]:


origin.value_counts()


# The value europe appears ... 70 times!

# # Well Done!

# ------------------------------------------------------------

# # Hints (Spoiler!)

# 18. mpg

# 19. describe() method

# 20. max() method

# 21. value_counts() method

# 22. normalize parameter

# 23. sort_values() method

# 24. ascending & inplace parameter

# 25. sort_index() method; inplace parameter

# 26. 235.21/mpg

# 27. describe() method

# 28. cars.---.---()

# 29. describe() method

# 30. unique() method

# 31. value_counts() method

# In[ ]:




