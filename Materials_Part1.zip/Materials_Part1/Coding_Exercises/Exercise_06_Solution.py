#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct.

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## Manipulating elements in a DataFrame / Slice

# ### Exercise 6: Manipulating elements in a DataFrame / Slice 

# In[ ]:


# run the cell!
import pandas as pd


# In[ ]:


# run the cell!
cars = pd.read_csv("cars.csv")


# In[ ]:


# run the cell!
cars


# 50. __Create a subset__ of the DataFrame __cars__ with all cars having an __mpg higher than 40__! __Save__ the subset in the variable __high_eff__!<br>
# __high_eff__ should be a new and __independent__ DataFrame. Any changes in high_eff shall __not influence__ the original DataFrame __cars__!
# 

# In[ ]:


high_eff = cars.loc[cars.mpg > 40].copy()


# 51. __Cap__ the __mpg__ for all cars in __high_eff__ to __40__ (Overwrite the mpg values)! Your code should not cause any warning message!

# In[ ]:


high_eff.mpg = 40


# __Inspect__ high_eff! In the column __"mpg"__, all values should be __40__!

# In[ ]:


# run the cell!
high_eff


# __Check__ in the original __cars__ Dataframe, whether there are still __values greater than 40__ in the __"mpg"__ column! <br>
# If so, your code is correct!

# In[ ]:


# run the cell!
cars.mpg.max()


# 52. Now, we want to __manipulate the original__ DataFrame __cars__. __Cap__ all mpg values __greater than 40__ to 40! Your code should not cause any warning message!

# In[ ]:


cars.loc[cars.mpg > 40, "mpg"] = 40


# __Check__, whether there are any values __greater than 40__ in the __"mpg"__ column of the __cars__ DataFrame. If so, your code was incorrect!

# In[ ]:


# run the cell!
cars.mpg.max()


# # Well Done!

# -------------------------

# # Hints (Spoiler!)

# 50. cars.loc[ --- ].copy()

# 51. --- = 40

# 52. no chained indexing, no copy() method

# In[ ]:




