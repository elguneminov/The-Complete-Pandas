#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct.

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## DataFrame Basics III

# ### Exercise 8: apply(), MultiIndex and Strings

# In[1]:


# run the cell!
import pandas as pd


# In[2]:


# run the cell!
cars = pd.read_csv("cars.csv")


# In[3]:


# run the cell!
cars


# 61. __Calculate__ for all __numerical columns__ the __range between highest and lowest__ value! __Fill in the gaps!__ The range for __mpg__ is...?

# In[4]:


cars.iloc[:, :-2].apply(lambda x: x.max() - x.min(), axis = 0)


# The range for mpg is ... 37.6!

# 62. Create a __MultiIndex__ for the __cars__ DataFrame with the columns __"model_year"__ (outer level) and __"origin"__ (inner level). __Save__ the change!

# In[5]:


cars.set_index(["model_year", "origin"], inplace = True)


# 63. __Sort__ both index levels in __ascending__ order! __Save__ the change!

# In[6]:


cars.sort_index(ascending = True, inplace = True )


# __Inspect__ Cars! What is the __name__ of the __second__ car?

# In[7]:


# run the cell!
cars


# The name of the second car is ... peugeot 504!

# 64. __Select__ all cars with the "model_year" __75__!

# In[8]:


cars.loc[75]


# 65. __Select__ all cars with the "model_year" __76__ from __japan__! __How many__ cars do we get?

# In[9]:


cars.loc[(76, "japan")]


# There are ... 4 cars!

# 66. __Select__ all cars with the "model_year" __77__ and __79__  from __japan__! And only the columns __"mpg"__ and __"name"__! What is the __mpg__ of __datsun 210__?

# In[10]:


cars.loc[([77,79], "japan"), ["mpg", "name"]]


# The mpg of datsun 210 is ... 31.8!

# 67. __Swap the levels__ of the MultiIndex and then __sort__ the new MultiIndex in __ascending__ order! __Reassign cars__! __Fill in the gaps__!

# In[11]:


cars = cars.swaplevel().sort_index(ascending = True)


# In[12]:


# run the cell!
cars


# 68. __Reset__ the __index__ of __cars__ and create a RangeIndex! __Save__ the change!

# In[13]:


cars.reset_index(inplace = True)


# In[14]:


# run the cell!
cars


# 69. __Convert__ all elements in the __origin__ column to __titlecase__! __Overwrite__ the __origin__ column!

# In[15]:


cars.origin = cars.origin.str.title()


# In[16]:


# run the cell!
cars


# Now, we want to __extract the manufacturer names__ from the column __"name"__. <br>
# 70. __Split__ the strings in the column __"name"__ on the very __first whitespace__ and __expand__ the splitted strings into __separate columns__! __Save__ new DataFrame in the variable __split__! __Fill in the gaps!__

# In[17]:


split = cars.name.str.split(pat = " ", n = 1, expand = True)


# __Inspect__!

# In[18]:


# run the cell!
split


# 71. __Select__ the __first column__ and determine the __frequency of unique values__. __Fill in the gaps__! Which manufacturer is __most frequent__?

# In[19]:


split[0].value_counts()


# There are 51 cars from the manufacturer ... Ford!

# 72. Let´s __doublecheck__ the result from above. Check __how many__ car names in the column "names" __contain "ford"__!

# In[20]:


cars.name.str.contains("ford").sum()


# It´s ... again 51! It seems that the very first word in the column "name" is always the manufacturer name.

# # Well Done!

# ------------------------------

# # Hints (Spoiler!)

# 61. apply() method, maximum - minimum

# 62. set_index() method, pass list with column labels

# 63. sort_index() method

# 64. pass outer index labels to loc operator

# 65. cars.loc[(outer index labels, inner index labels)]

# 66. cars.loc[(outer index labels, inner index labels), column labels]

# 67. methods swaplevel() and sort_index()

# 68. reset_index() method

# 69. string(str)-method title()

# 70. string(str)-method split(), n = 1, 

# 71. value_counts() method 

# 72. string(str)-method contains()

# In[ ]:




