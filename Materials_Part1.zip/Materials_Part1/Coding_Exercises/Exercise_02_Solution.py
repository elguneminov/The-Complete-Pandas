#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct.

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## Pandas Basics (DataFrame Basics I)

# ### Exercise 2: Indexing and Slicing

# 7. __Import Pandas__ (as pd), <br>
# __Import__ the Cars Dataset (__cars.csv__) and save the DataFrame in the variable __cars__ and<br>
# __Inspect/Print__ cars!

# In[ ]:


import pandas as pd


# In[ ]:


cars = pd.read_csv("cars.csv")


# In[ ]:


cars


# 8. Select the column __"name"__ with the __attribute__ (dot) notation! What is the __name__ of the car with __index label 393__?

# In[ ]:


cars.name


# The name is ... ford mustang gl!

# 9. Apply also the __second alternative__ to select the column __"name"__!

# In[ ]:


cars["name"]


# 10. __Select__ the car/row at __index position 100__ with the __iloc__ operator (all columns)! How many __cylinders__ does the car have?

# In[ ]:


cars.iloc[100]


# The car has ... 6 cylinders!

# 11. Select the car/row at __index position 200__ with the __iloc__ operator (and only the column __"name"__)! <br>
# What is the __name__ of the car?

# In[ ]:


cars.iloc[200, 8]


# It´s a ... ford granada ghia!

# 12. Select the __last 10 rows__ and the columns __mpg, horsepower, origin__ and __name__ with the __iloc__ operator! __Fill in the Gaps__! <br>
# What is the __mpg__ of the __vw pickup__?

# In[ ]:


cars.iloc[-10:, [0, 3, 7, 8]]


# The mpg is ... 44.0!

# 13. __Import__ the __Cars Dataset__ one more time (save in the variable __cars__) and set the column __"name"__ as the __index__! <br>
# __Fill in the Gaps__!

# In[ ]:


cars = pd.read_csv("cars.csv", index_col = "name")


# In[ ]:


#run the cell and inspect!
cars


# In[ ]:


#run the cell and inspect!
cars.info()


# 14. __Inspect__ the new Index of the DataFrame by calling the __index__ attribute!

# In[ ]:


cars.index


# 15. Select the __row__ with the index label __"ford ranger"__ (use the __loc__ operator)! What is the __weight__?

# In[ ]:


cars.loc["ford ranger"]


# The weight is ... 2625!

# 16. Select the __row__ with the index label __"ford torino"__ and only the columns __"model_year"__ and __"origin"__! <br>
# What´s the __model year__?

# In[ ]:


cars.loc["ford torino", ["model_year", "origin"]]


# The model year is ... 70!

# 17. Select the columns __"mpg"__ and __"weight"__ (all rows) with the __loc__ operator!

# In[ ]:


cars.loc[:, ["mpg", "weight"]]


# # Well Done!

# ---------------------------------------------------------------------------------------------------------------------

# # Hints (Spoiler!)

# 7. pandas as pd, pd.read_csv("filename"), head()

# 8. cars.---

# 9. cars["---"]

# 10. cars.iloc[---]

# 11. cars.iloc[row index position, column index position]; "name" column is at index position ... 8

# 12. The last 10 rows = from index position -10 till the end (:); Count the column index positions of the Columns
# 

# 13. parameter index_col

# 14. cars.---

# 15. cars.loc["row label"]

# 16. cars.loc[---, [---, ---]]

# 17.  cars.loc[ : , [---, ---]]

# In[ ]:




