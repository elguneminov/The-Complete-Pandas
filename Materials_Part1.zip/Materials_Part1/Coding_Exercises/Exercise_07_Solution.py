#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct.

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## DataFrame Basics III

# ### Exercise 7: Sorting, Ranking & Summary Statistics

# In[ ]:


# run the cell!
import pandas as pd


# In[ ]:


# run the cell!
cars = pd.read_csv("cars.csv")


# In[ ]:


# run the cell!
cars


# 53. __Sort__ the __cars__ DataFrame by the __"mpg"__ column from __high to low__ and __save__ the new order!

# In[ ]:


cars.sort_values(by = "mpg", ascending = False, inplace= True)


# __Inspect__ cars! What is the __name__ of the __most fuel efficient__ car?

# In[ ]:


#run the cell!
cars


# The most fuel efficient car is ... mazda glc!

# 54. __Sort__ the __cars__ DataFrame by the __index__ from __low to high__. __Save__ the order!

# In[ ]:


cars.sort_index(ascending = True, inplace= True)


# In[ ]:


# run the cell!
cars


# 55. __Create__ a new column __"hp_rank"__ with the __horsepower rank__ for each car (__rank 1__ means __highest__ horsepower)! __Fill in the gaps!__

# In[ ]:


cars["hp_rank"] = cars.horsepower.rank(method = "min", ascending = False)


# 56. __Sort cars__ by the __"horsepower"__ from __high to low__. The __"hp_rank"__ for the car __"pontiac grand prix"__ is...? 

# In[ ]:


cars.sort_values(by = "horsepower", ascending = False)


# The __"hp_rank"__ for the car __"pontiac grand prix"__ is... 1!

# 57. Check the amount of __unique values__ in __all columns__ of the cars DataFrame! __How many__ unique values are in the __"name"__ column?

# In[ ]:


cars.nunique()


# There are ... 300 unique values in the "name" column! (There must be 98 name duplicates!)

# 58. __Select__ the __10__ cars with the __highest weights__!

# In[ ]:


cars.nlargest(n = 10, columns = "weight")


# 59. Call an appropriate method on the __cars__ DataFrame that provides plenty of __summary statistics__!

# In[ ]:


cars.describe()


# 60. Create a __correlation matrix__ for the __cars__ DataFrame! Which factor has the __highest negative correlation__ to __mpg__?

# In[ ]:


cars.corr()


# The factor weight shows the highest negative correlation to mpg! The lower the weight, the higher the fuel efficiency!

# # Well Done!

# ------------------------------

# # Hints (Spoiler!)

# 53. sort_values() method

# 54. sort_index() method

# 55. rank() method, descending order

# 56. sort_values() method

# 57. nunique() method

# 58. nlargest() method

# 59. describe() method

# 60. corr() method

# In[ ]:




