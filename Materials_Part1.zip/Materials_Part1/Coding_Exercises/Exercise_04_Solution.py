#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## Pandas Index Objects
# 

# ### Exercise 4: Index Operations

# In[ ]:


#run the cell!
import pandas as pd


# In[ ]:


#run the cell!
cars = pd.read_csv("cars.csv")


# In[ ]:


#run the cell!
cars


# In[ ]:


#run the cell!
cars.info()


# 32. __Select__ the __index__ (row labels) of the DataFrame __cars__! What __kind of index__ do we have?

# In[ ]:


cars.index


# It´s a ... RangeIndex!

# 33. __Set__ the __"name"__ column as the __new index__ of cars (save the changes)!

# In[ ]:


cars.set_index("name", inplace = True)


# 34. __Check__ whether the new index contains __only unique values__ (no duplicates)! Is this the case?

# In[ ]:


cars.index.is_unique


# No, apparently, there are duplicate entries!

# 35. __Get__ the __frequency/Counts__ of all unique values in the index! What is the __most frequent__ value?

# In[ ]:


cars.index.value_counts()


# The most frequent value is ... ford pinto!

# 36. __Set__ the __name__ of the index to __"car_model"__!

# In[ ]:


cars.index.name = "car_model"


# In[ ]:


#run the cell!
cars


# 37. __Reset__ the __index__ to a RangeIndex and __save__ the change!

# In[ ]:


cars.reset_index(inplace= True)


# In[ ]:


#run the cell!
cars


# 38. __Inspect__ the __column Index__!

# In[ ]:


cars.columns


# 39. __Rename__ the column __Labels__ "horsepower" and "origin" to "hp" and "country"! __Fill in  the gaps__!

# In[ ]:


cars.rename(columns = {"horsepower":"hp", "origin":"country"}, inplace = True)


# In[ ]:


#run the cell!
cars


# # Well Done!

# ------------------------------------------------------------

# # Hints (Spoiler!)

# 32. index attribute

# 33. set_index() method; inplace parameter

# 34. call is_unique attribute on index

# 35. call value_counts() method on index

# 36. cars.index.---  =  "car_model"

# 37. reset_index() method; inplace parameter

# 38. columns attribute

# 39. rename() method; columns parameter

# In[ ]:




