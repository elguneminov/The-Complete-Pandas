#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct.

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## Pandas Basics (DataFrame Basics I)

# ### Exercise 1: Importing and Inspecting your own Dataset

# Before we can work with the Pandas Library, we need to __import Pandas__ (by convention as __pd__). <br>
# 1. __Import__ Pandas. __Fill in the gaps__!

# In[ ]:


import pandas as pd


# Now we want to import the __Cars Dataset__ that is stored in the CSV-File __cars.csv__. <br>
# 2. __Import__ the Cars Dataset and __store__ the Pandas DataFrame in the variable __cars__! __Fill in the gaps__!

# In[ ]:


cars = pd.read_csv("cars.csv")


# #### Some more details on the Columns:
# 
# - __mpg__: Measures __fuel efficiency__ in terms of miles per gallon. __Higher mpg__ means __higher efficiency__
# - __cylinders__: Number of cylinders in the car
# - __displacement__: Technical feature (engine)
# - __horsepower__: Unit of measurement for engine power 
# - __weight__: weight in lbs
# - __acceleration__: time to accelerate from 0 to 60 mph (sec.)
# - __model_year__: self explanatory
# - __origin__: origin of the manufacturer/car
# - __name__: model name

# 3a. __Inspect__ the DataFrame cars by "printing" cars!

# In[ ]:


cars


# 3b. __Inspect__ the __first 10 Rows__ of the DataFrame cars! __Fill in the gaps__! What is the __name of the very first car__ in the first row (index label/pos = 0)?

# In[ ]:


cars.head(10)


# It´s a ... Chevrolet Chevelle Malibu!

# 3c. Also inspect the __last 5 Rows__! __How many cars/rows__ do we have in the Dataset (mind the range index starting from 0!)?

# In[ ]:


cars.tail()


# We have ... 398 Cars!

# 4. __Inspect__ the entire DataFrame (__all rows__)! __Fill in the gaps!__

# In[ ]:


pd.options.display.max_rows = 400


# In[ ]:


cars


# 5. Get some __meta information__ on our DataFrame! In which __Column__ do we have __missing/NaN__ Values?

# In[ ]:


cars.info()


# We have 6 missing/NaN Values in the column ... horsepower!

# 6. Let´s get some __summary statistics__ on our DataFrame! What is the __maximum__ value in the column __horsepower__?

# In[ ]:


cars.describe()


# The maximum value in the column horsepower is ... 230!

# -------------------------------

# # Well Done!

# ---------------------------------------------------------------------------------------------------------------------

# # Hints (Spoiler!)

# 1. pandas as pd

# 2. Pass the filename in quotation marks to pd.read_csv()

# 3a. cars

# 3b. head() method with n = 10

# 3c. tail() method

# 4. max_rows 

# 5. info() method

# 6. describe() method

# In[ ]:




