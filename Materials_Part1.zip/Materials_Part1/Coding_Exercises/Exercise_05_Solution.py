#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct.

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## DataFrame Basics II

# ### Exercise 5: Filtering DataFrames & Adding/Removing Rows and Columns

# In[ ]:


#run the cell!
import pandas as pd


# In[ ]:


#run the cell!
cars = pd.read_csv("cars.csv")


# In[ ]:


#run the cell!
cars


# 40. __Check__ for all elements in the column __"origin"__ whether they are __equal to "europe"__. __Save__ the boolean Series in the variable __mask1__! __Fill in the gaps__!

# In[ ]:


mask1 = cars.origin == "europe"
mask1


# 41. __Check__ for all elements in the column __"mpg"__ whether they are __smaller than 20__. __Save__ the boolean Series in the variable __mask2__!

# In[ ]:


mask2 = cars.mpg < 20


# 42. __Filter__ the cars DataFrame for __all cars from europe__ (use mask1) and __save__ the subset in the variable __europe__! __Fill in the gaps!__

# In[ ]:


europe  = cars.loc[mask1].copy()


# __Inspect__! What is the name of the __second__ car?

# In[ ]:


# run the cell!
europe


# The second car is a ... peugeot 504!

# 43. Get some __meta information__ on the DataFrame europe. __How many__ cars are from europe? 

# In[ ]:


europe.info()


# ... 70 cars are from europe!

# 44. __Filter__ the DataFrame __cars__ for all cars __from europe with low fuel efficiency__ (mpg lower than 20). Use __mask1__ and __mask2__!<br> __Save__ the subset in the variable __europe_le__! __Fill in the gaps__!

# In[ ]:


europe_le = cars.loc[mask1 & mask2].copy()


# __Inspect__! What is the __name__ of the __least efficient__ car from europe? 

# In[ ]:


#run the cell!
europe_le


# The least efficient european car is ... peugeot 604sl

# 45. __Filter__ the DataFrame cars for all cars with an __mpg between 10 and 15__ (both ends inclusive!). <br>
#  __Save__ the subset in the variable __mpg_10_15__! __Fill in the gaps__!

# In[ ]:


mpg_10_15 = cars.loc[cars.mpg.between(10,15)].copy()


# __Inspect__! The __first__ car is...?

# In[ ]:


# run the cell!
mpg_10_15


# The __first__ car is... buick skylark 320!

# __Inspect__! __How many__ cars are in the subset?

# In[ ]:


#run the cell!
mpg_10_15.info()


# There are ... 68 cars!

# 46. __Filter__ the Dataframe __cars__ for all cars that are __not built in the years 73 and 74__, and only the columns __"mpg"__ and __"name"__!<br> __Save__ the subset in the variable __not_73_74__. __Fill in the gaps!__ 

# In[ ]:


not_73_74 = cars.loc[~cars.model_year.isin([73, 74]), ["mpg", "name"]].copy()


# In[ ]:


#run the cell!
not_73_74


# __Inspect__! __How many__ cars are in this subset?

# In[ ]:


# run the cell!
not_73_74.info()


# There are ... 331 cars in the subset! 

# In[ ]:


# run the cell!
cars


# 47. __Drop__ the columns __"displacement"__ and __"cylinders"__ from the DataFrame cars! __Save__ the change!

# In[ ]:


cars.drop(columns = ["displacement", "cylinders"], inplace = True)


# In[ ]:


# run the cell!
cars


# 48. __Drop__ all rows/cars from __"usa"__ from the DataFrame cars! Use the __loc__ operator and __overwrite cars__!

# In[ ]:


cars = cars.loc[cars.origin != "usa"]


# In[ ]:


# run the cell!
cars


# 49. __Add__ the new column __"l_per_100km"__ to the DataFrame cars by calculating __235.21/mpg__. __Round__ to 2 decimals. __Fill in the gaps__!

# In[ ]:


cars["l_per_100km"] = (235.21/cars.mpg).round(2)


# __Inspect__ cars! What is the __"l_per_100km"__ value for the __audi 100 ls__?

# In[ ]:


# run the cell!
cars


# The "l_per_100km" value for the audi 100 ls is ... 9.80!

# # Well Done!

# ---------------------------------

# # Hints (Spoiler!)

# 40. origin attribute; "europe"

# 41. mask2  =  cars.---  <  --- 

# 42. loc operator, mask1

# 43. info() method

# 44. Condition1 & Condition2

# 45. between() method

# 46. isin() method and ~ (tilde symbol)

# 47. drop() method

# 48. use != (not equal)

# 49. cars["new_column_label"]

# In[ ]:




