#!/usr/bin/env python
# coding: utf-8

# # Coding Exercises (Part 1)

# Now, you will have the opportunity to analyze your own dataset. <br>
# __Follow the instructions__ and insert your code! You are either requested to 
# - Complete the Code and __Fill in the gaps__. Gaps are marked with "__---__" and are __placeholders__ for your code fragment. 
# - Write Code completely __on your own__ 

# In some exercises, you will find questions that can only be answered, if your code is correct and returns the right output! The correct answer is provided below your coding cell. There you can check whether your code is correct.

# If you need a hint, check the __Hints Section__ at the end of this Notebook. Exercises and Hints are numerated accordingly.

# If you need some further help or if you want to check your code, you can also watch the __solutions videos__ or check the __solutions notebook__.

# ### Have Fun!

# --------------------------------------------------------------------------------------------------------------

# ## Visualization with Matplotlib

# ### Exercise 9: Plotting Data with Matplotlib

# In[ ]:


# run the cell!
import pandas as pd


# In[ ]:


# run the cell!
cars = pd.read_csv("cars.csv")


# In[ ]:


# run the cell!
cars


# 73. __Import__ matplotlib.pyplot (as plt) and set the __style__ to __"seaborn"__! __Fill in the gaps!__

# In[ ]:


import matplotlib.pyplot as plt
plt.style.use("seaborn")


# 74. __Create__ the graph below (lineplot for all numerical columns)!

# ![image.png](attachment:image.png)

# In[ ]:


cars.plot(subplots = True, sharex = False, figsize = (15,15))
plt.show()


# 75. __Create__ the graph below (Histogramm for the __"mpg"__ column with 40 bins)!

# ![image.png](attachment:image.png)

# In[ ]:


cars.mpg.hist(figsize = (12,8), bins = 40 )
plt.title("MPG", fontsize = 15)
plt.xlabel("mpg", fontsize = 13)
plt.ylabel("frequency", fontsize = 13)
plt.show()


# 76. __Create__ the graph below (Scatterplot with __horsepower__ and __mpg__)! __Fill in the gaps!__

# ![image.png](attachment:image.png)

# In[ ]:


cars.plot(kind = "scatter", x = "horsepower", y = "mpg", figsize = (12,8), c = "cylinders", marker = "x", colormap = "viridis")
plt.title("MPG vs. Horsepower", fontsize = 18)
plt.xlabel("horsepower", fontsize = 15)
plt.ylabel("mpg", fontsize = 15)
plt.show()


# # Well Done!

# -----------------------------

# # Hints (Spoiler!)

# 73. plt.style.use()

# 74. plot() method, figure size = (15,15), subplots shall not share x-axis, don´t forget plt.show()

# 75. hist() method, plt.title(), plt.xlabel(), plt.ylabel(), plt.show(), fontsize for title: 15, fontsize for labels: 13, figure size: (12,8)

# 76. "scatter" plot, color of points determined by cylinders column

# In[ ]:




