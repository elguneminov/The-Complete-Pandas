#!/usr/bin/env python
# coding: utf-8

# # Part 2: Full Data Workflow A-Z

# ## Importing CSV Files with pd.read_csv()

# ### First Steps

# In[ ]:


with open('titanic.csv') as f:
    text = f.readlines()


# In[ ]:


text


# In[ ]:


len(text)


# In[ ]:


print("Hello \nWorld!")


# In[ ]:


import pandas as pd


# In[ ]:


pd.read_csv("titanic.csv")


# In[ ]:


pd.read_csv("titanic.csv", index_col= "pclass")


# In[ ]:


pd.read_csv("titanic.csv", header = None)


# In[ ]:


pd.read_csv("titanic.csv", header = None, names= ["Alive", "Class", "Gender", "Age", "SipSp", "ParCh", "Fare", "Emb", "Deck"])


# In[ ]:


pd.read_csv("titanic.csv", header = 0, names= ["Alive", "Class", "Gender", "Age", "SipSp", "ParCh", "Fare", "Emb", "Deck"])


# In[ ]:


pd.read_csv("titanic.csv", usecols=["pclass", "survived", "sex", "age"])


# In[ ]:


titanic = pd.read_csv("titanic.csv", index_col= "pclass", usecols= ["pclass", "survived", "sex", "age"])


# In[ ]:


titanic.head()


# In[ ]:


titanic.columns = ["Alive", "Gender", "Age"]


# In[ ]:


titanic.index.name = "Class"


# In[ ]:


titanic.head()


# In[ ]:





# ### Importing messy CSV Files

# In[ ]:


import pandas as pd


# In[ ]:


pd.read_csv("titanic_raw.csv")


# In[ ]:


col_names = ["Survived", "Class", "Gender", "Age", "SipSp", "ParCh", "Fare", "Emb", "Deck"]


# In[ ]:


titanic = pd.read_csv("titanic_raw.csv", skiprows= 3, skipfooter= 2, header = None, names = col_names)


# In[ ]:


titanic.head()


# In[ ]:


titanic.to_csv("titanic_imp.csv", index=False)


# In[ ]:


pd.read_csv("titanic_imp.csv")


# In[ ]:




