#!/usr/bin/env python
# coding: utf-8

# # Part 2: Full Data Workflow A-Z

# ## Reshaping DataFrames

# ### Transposing DataFrames

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.T


# In[ ]:


titanic.transpose()


# In[ ]:


titanic.info()


# In[ ]:


titanic = titanic.transpose()


# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


titanic = titanic.T


# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


titanic.survived.mean()


# In[ ]:


#titanic.groupby(["sex", "pclass"]).survived.mean()


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.info()


# In[ ]:


titanic.groupby(["sex", "pclass"]).survived.mean().unstack().T


# In[ ]:


titanic.T.T.info()


# In[ ]:





# ### Pivoting DataFrames with pivot()

# In[ ]:


import pandas as pd


# In[ ]:


table1 = pd.read_csv("table1.csv")


# In[ ]:


table1.head(10)


# In[ ]:


table1.tail(10)


# In[ ]:


table1.info()


# In[ ]:


table1.shape


# In[ ]:


table1.pivot(index = "Country", columns = "Medal", values = "Count")


# In[ ]:


table1_piv = table1.pivot(index = "Country", columns = "Medal", values = "Count").fillna(0)


# In[ ]:


table1_piv


# In[ ]:


table1_piv.shape


# In[ ]:


table1_piv.info()


# In[ ]:


table1.head()


# In[ ]:


table1.set_index(["Country", "Medal"]).unstack(fill_value = 0)


# In[ ]:


table1_piv


# In[ ]:





# ### Limits of pivot()

# In[ ]:


import pandas as pd


# In[ ]:


table2 = pd.read_csv("table2.csv")


# In[ ]:


table2.head(20)


# In[ ]:


table2.tail(10)


# In[ ]:


table2.info()


# In[ ]:


table2.shape


# In[ ]:


table2.pivot(index = "Country", columns = "Medal", values = "Count")


# In[ ]:


table2.groupby(["Country", "Year", "Medal"]).Count.sum().unstack().fillna(0)


# In[ ]:


table2_piv = table2.groupby(["Country", "Year", "Medal"]).Count.sum().unstack().fillna(0)


# In[ ]:


table2_piv


# In[ ]:


table2_piv.info()


# In[ ]:


table2_piv.shape


# In[ ]:





# ### pivot_table()

# In[ ]:


import pandas as pd


# In[ ]:


table2 = pd.read_csv("table2.csv")


# In[ ]:


table2.head(10)


# In[ ]:


table2.pivot_table(index = "Country", columns = "Medal", values = "Count", aggfunc="sum", fill_value= 0, margins= True, margins_name="Total")


# In[ ]:


table2.groupby(["Country", "Medal"]).Count.sum().unstack(fill_value = 0)


# In[ ]:


agg = table2.groupby(["Country", "Medal"]).Count.sum().unstack(fill_value = 0)


# In[ ]:


agg.head()


# In[ ]:


agg["All"] = agg.sum(axis = 1)


# In[ ]:


agg.loc["All"] = agg.sum(axis = 0)


# In[ ]:


agg


# In[ ]:





# ### pd.crosstab()

# In[ ]:


import pandas as pd


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


pd.crosstab(titanic.sex, titanic.pclass, margins=True, normalize= True)


# In[ ]:


titanic.groupby(["sex", "pclass"]).pclass.count().unstack()


# In[ ]:


pd.crosstab(index = titanic.sex, columns =  titanic.pclass, values=titanic.age, aggfunc="mean")


# In[ ]:


titanic.pivot_table(index = "sex", columns = "pclass", values = "age", aggfunc = "mean")


# In[ ]:


titanic.groupby(["sex", "pclass"]).age.mean().unstack()


# In[ ]:


pd.crosstab(index = titanic.sex, columns =  titanic.pclass, values = titanic.fare, aggfunc = "sum", margins=True, normalize= True)


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


summer.info()


# In[ ]:


pd.crosstab(index = [summer.Year, summer.Country], columns = summer.Medal, aggfunc = "count",
            values = summer.Athlete, margins = True).fillna(0)


# In[ ]:


summer.pivot_table(index=["Year", "Country"], columns = "Medal", aggfunc = "count",
                   values = "Athlete", fill_value=0, margins = True)


# In[ ]:


summer.groupby(["Year", "Country", "Medal"]).Medal.count().unstack(fill_value = 0)


# In[ ]:





# ### Melting DataFrames with melt()

# In[ ]:


import pandas as pd


# In[ ]:


table_2012 = pd.read_csv("table_2012.csv")


# In[ ]:


table_2012


# In[ ]:


table_2012.shape


# In[ ]:


table_2012.melt(id_vars = "Country", value_vars = ["Gold", "Silver", "Bronze"], var_name="Medal", value_name="Count")


# In[ ]:


melt_2012 = table_2012.melt(id_vars = "Country", value_vars = ["Gold", "Silver", "Bronze"], 
                            var_name = "Medal", value_name = "Count")


# In[ ]:


melt_2012


# In[ ]:


melt_2012.pivot(index = "Country", columns = "Medal", values = "Count").sort_values("Gold", ascending = False)


# In[ ]:




