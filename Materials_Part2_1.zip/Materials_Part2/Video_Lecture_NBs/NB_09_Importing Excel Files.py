#!/usr/bin/env python
# coding: utf-8

# # Part 2: Full Data Workflow A-Z

# ## Importing from Excel Files with pd.read_excel()

# ### First Steps

# In[ ]:


import pandas as pd


# In[ ]:


sales = pd.read_excel("sales.xls", index_col= 0)


# In[ ]:


sales


# In[ ]:


sales.info()


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0)


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0, names = ["Name", "Loc_City", "Loc_Country", "Revenue", "Add_Comp"])


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = "A:C")


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = "C:E")


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = "A, C:E")


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = ":C")


# In[ ]:


#pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = "C:")


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = [0,3,4])


# In[ ]:


#pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = 2)


# In[ ]:


pd.read_excel("sales.xls", index_col = 0, header = 0, usecols = ["City", "Sales"])


# In[ ]:





# ### Customizing import with pd.read_excel()

# In[ ]:


import pandas as pd


# In[ ]:


pd.read_excel("summer_raw.xls")


# In[ ]:


pd.read_excel("summer_raw.xls", sheet_name = 1)


# In[ ]:


pd.read_excel("summer_raw.xls", sheet_name = "summer", skiprows= [0,1])


# In[ ]:


pd.read_excel("summer_raw.xls", sheet_name = "summer", skiprows= 2, usecols= "D:L")


# In[ ]:


summer = pd.read_excel("summer_raw.xls", sheet_name = "summer", skiprows= 2, usecols= "D:L")


# In[ ]:


summer.head()


# In[ ]:


summer.tail()


# In[ ]:


summer.info()


# In[ ]:


summer.to_csv("summer_imp.csv", index= False)


# In[ ]:


summer.to_excel("summer_imp.xls")


# In[ ]:


pd.read_csv("summer_imp.csv")


# In[ ]:




