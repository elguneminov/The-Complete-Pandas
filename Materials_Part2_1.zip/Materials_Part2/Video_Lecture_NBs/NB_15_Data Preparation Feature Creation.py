#!/usr/bin/env python
# coding: utf-8

# # Part 2: Full Data Workflow A-Z

# ## Data Preparation and Feature Creation

# ### Arithmetic Operations

# In[ ]:


import pandas as pd
import numpy as np


# In[ ]:


titanic = pd.read_csv("titanic.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


titanic.age.fillna(titanic.age.mean(), inplace = True)


# In[ ]:


titanic.head(10)


# In[ ]:





# #### Add/Sub/Mul/Div of Columns

# In[ ]:


titanic.sibsp + titanic.parch


# In[ ]:


titanic.sibsp.add(titanic.parch)


# In[ ]:


titanic["no_relat"] = titanic.sibsp.add(titanic.parch)


# In[ ]:


titanic.head()


# In[ ]:


sales = pd.read_csv("sales.csv", index_col = 0)


# In[ ]:


sales


# In[ ]:


sales.Mon + sales.Thu


# In[ ]:


sales.Mon.add(sales.Thu, fill_value=0)


# In[ ]:


sales["perc_Bonus"] = [0.12, 0.15, 0.10, 0.20]


# In[ ]:


sales


# In[ ]:


sales.Thu * sales.perc_Bonus


# In[ ]:


sales.Thu.mul(sales.perc_Bonus, fill_value=0)


# In[ ]:


sales.iloc[:, :-1].sum(axis = 1).mul(sales.perc_Bonus)


# In[ ]:


sales["Bonus"] = sales.iloc[:, :-1].sum(axis = 1).mul(sales.perc_Bonus)


# In[ ]:


sales


# #### Add/Sub/Mul/Div with Scaler Value

# In[ ]:


titanic.head()


# In[ ]:


1912 - titanic.age


# In[ ]:


titanic["YoB"] = titanic.age.sub(1912).mul(-1)


# In[ ]:


titanic.head()


# In[ ]:


fx_rate = 1.1


# In[ ]:


titanic["EUR_fare"] = titanic.fare.div(fx_rate)


# In[ ]:


titanic.head()


# In[ ]:


titanic.drop(columns = ["sibsp", "parch", "deck", "YoB", "EUR_fare"], inplace =True)


# In[ ]:


titanic.head()


# In[ ]:


sales


# In[ ]:


fixed_costs = 5


# In[ ]:


sales.iloc[:, :-2].sub(fixed_costs, fill_value = 0)


# In[ ]:


perc_Bonus = 0.1


# In[ ]:


sales.iloc[:, :-2].mul(perc_Bonus, fill_value = 0)


# In[ ]:


sales.iloc[:,:-2]


# In[ ]:


lot_size = 10
bonus_per_lot = 1.25


# In[ ]:


sales.iloc[:, :-2].floordiv(lot_size, fill_value = 0).mul(bonus_per_lot).sum(axis = 1)


# In[ ]:





# ### Transformation / Mapping

# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


sample = summer.sample(n = 7, random_state = 123).sort_values(by = "Year")


# In[ ]:


sample


# In[ ]:


city_country = {"Paris":"France", "Mexico":"Mexico", "Montreal":"Canada", "Moscow":"Russia", "Barcelona":"Spain", "Athens": "Greece"}


# In[ ]:


city_country


# In[ ]:


sample.City.map(city_country)


# In[ ]:


sample["Host_Country"] = sample.City.map(city_country)


# In[ ]:


sample


# In[ ]:


titanic.head()


# In[ ]:


mapper = {1:"First", 2:"Second", 3:"Third"}


# In[ ]:


titanic.pclass.map(mapper)


# In[ ]:


titanic.pclass = titanic.pclass.map(mapper)


# In[ ]:


titanic.head()


# In[ ]:





# ### Conditional Transformation

# In[ ]:


titanic.head(10)


# In[ ]:


titanic.no_relat == 0


# In[ ]:


pd.Series(np.where(titanic.no_relat == 0, "Yes", "No"))


# In[ ]:


titanic["alone"] = pd.Series(np.where(titanic.no_relat == 0, "Yes", "No"))


# In[ ]:


titanic.head(10)


# In[ ]:


titanic["child"] = pd.Series(np.where(titanic.age < 18, "Yes", "No"))


# In[ ]:


titanic.head(10)


# In[ ]:





# ### Discretization and Binning with pd.cut() (Part 1)

# In[ ]:


titanic.head(10)


# In[ ]:


age_bins = [0, 10, 18, 30, 55, 100]


# In[ ]:


cats = pd.cut(titanic.age, age_bins, right = False)


# In[ ]:


cats


# In[ ]:


cats.value_counts()


# In[ ]:


titanic["age_cat"] = cats


# In[ ]:


titanic.head()


# In[ ]:


titanic.groupby("age_cat").survived.mean()


# In[ ]:


group_names = ["child", "teenager", "young_adult", "adult", "elderly"]


# In[ ]:


pd.cut(titanic.age, age_bins, right = False, labels = group_names)


# In[ ]:


titanic["age_cat"] = pd.cut(titanic.age, age_bins, right = False, labels = group_names)


# In[ ]:


titanic.head(10)


# In[ ]:


titanic.age_cat


# In[ ]:





# ### Discretization and Binning with pd.cut() (Part 2)

# In[ ]:


titanic.fare


# In[ ]:


pd.cut(titanic.fare, 5, precision= 3)


# In[ ]:


titanic["fare_cat"] = pd.cut(titanic.fare, 5, precision= 0)


# In[ ]:


titanic.head(10)


# In[ ]:


titanic.fare_cat.value_counts()


# In[ ]:





# ### Discretization and Binning with pd.qcut() 

# In[ ]:


titanic.head()


# In[ ]:


pd.qcut(titanic.fare, 5) 


# In[ ]:


titanic["fare_cat"] = pd.qcut(titanic.fare, 5) 


# In[ ]:


titanic.head()


# In[ ]:


titanic.fare_cat.value_counts()


# In[ ]:


pd.qcut(titanic.fare, [0, 0.1, 0.25, 0.5, 0.9, 1], precision = 0) 


# In[ ]:


fare_labels =["very_cheap", "cheap", "moderate", "exp", "very_exp"]


# In[ ]:


titanic["fare_cat"] =  pd.qcut(titanic.fare, [0, 0.1, 0.25, 0.5, 0.9, 1], precision = 0, labels = fare_labels) 


# In[ ]:


titanic.head()


# In[ ]:


titanic.fare_cat.value_counts()


# In[ ]:


titanic.groupby(["age_cat", "fare_cat"]).survived.mean().unstack()


# In[ ]:





# ### Caps and Floors

# In[ ]:


titanic.head()


# In[ ]:


import matplotlib.pyplot as plt


# In[ ]:


titanic.fare.plot(figsize = (12,8))
plt.show()


# In[ ]:


titanic.fare.describe()


# In[ ]:


titanic.fare.sort_values(ascending = False)


# In[ ]:


fare_cap = 250


# In[ ]:


titanic.loc[titanic.fare > fare_cap, "fare"] = fare_cap


# In[ ]:


fare_floor = 5


# In[ ]:


titanic.loc[titanic.fare < fare_floor, "fare"] = fare_floor


# In[ ]:


titanic.head()


# In[ ]:





# ### Scaling / Standardization

# In[ ]:


titanic.head()


# In[ ]:


titanic.describe()


# In[ ]:


import matplotlib.pyplot as plt


# In[ ]:


titanic.fare.plot(figsize = (12,8))
titanic.age.plot(figsize = (12,8))
plt.show()


# In[ ]:


mean_age = titanic.age.mean()
mean_fare = titanic.fare.mean()


# In[ ]:


std_age = titanic.age.std()
std_fare = titanic.fare.std()


# In[ ]:


titanic["age_z"] = round((titanic.age-mean_age) / std_age,2)
titanic["fare_z"] = round((titanic.fare-mean_fare) / std_fare,2)


# In[ ]:


titanic.head(10)


# In[ ]:


round(titanic.describe(),2)


# In[ ]:


titanic.fare_z.plot(figsize = (12,8))
titanic.age_z.plot(figsize = (12,8))
plt.show()


# In[ ]:


#titanic.to_csv("titanic_prep.csv", index = False)


# In[ ]:


titanic.head()


# In[ ]:


titanic.drop(labels = ["age", "alone", "child", "age_z", "fare_z", "fare_cat"], axis = 1, inplace = False)


# In[ ]:





# ### Creating Dummy Variables

# In[ ]:


titanic.head()


# In[ ]:


titanic.drop(labels = ["age", "alone", "child", "age_z", "fare_z", "fare_cat"], axis = 1, inplace = True)


# In[ ]:


titanic.head()


# In[ ]:


titanic_d = pd.get_dummies(titanic, columns = ["sex", "pclass", "embarked", "age_cat"], drop_first=True)


# In[ ]:


titanic_d.head()


# In[ ]:


titanic_d.info()


# In[ ]:





# ### String Operations

# In[ ]:


import pandas as pd


# In[ ]:


summer = pd.read_csv("summer.csv")


# In[ ]:


summer.head()


# In[ ]:


summer.Athlete = summer.Athlete.str.title()


# In[ ]:


summer.Athlete.str.split(", ", n = 1, expand = True)


# In[ ]:


summer[["Surname", "First_Name"]] = summer.Athlete.str.split(", ", n = 1, expand = True)


# In[ ]:


summer.head()


# In[ ]:


summer["Surname"] = summer.Surname.str.strip()


# In[ ]:


summer["First_Name"] = summer.First_Name.str.strip()


# In[ ]:


summer.drop(columns = "Athlete")


# In[ ]:




