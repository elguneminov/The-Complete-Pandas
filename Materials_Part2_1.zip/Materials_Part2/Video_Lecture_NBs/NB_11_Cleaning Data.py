#!/usr/bin/env python
# coding: utf-8

# # Part 2: Full Data Workflow A-Z

# ## Cleaning Data

# ### First Inspection / Handling inconsistent Data 

# In[ ]:


import pandas as pd


# #### Titanic Dataset

# In[ ]:


titanic = pd.read_csv("titanic_imp.csv")


# In[ ]:


titanic.head()


# In[ ]:


titanic.tail()


# In[ ]:


titanic.info()


# In[ ]:


titanic.describe()


# In[ ]:


titanic.describe(include ="O")


# In[ ]:


titanic.Survived.unique()


# In[ ]:


titanic.Survived.value_counts()


# In[ ]:


titanic.Survived.replace(to_replace= ["yes", "no"], value = [1, 0], inplace = True)


# In[ ]:


titanic.Survived.value_counts()


# #### Olympic Dataset

# In[ ]:


summer = pd.read_csv("summer_imp.csv")


# In[ ]:


summer.head()


# In[ ]:


summer.tail()


# In[ ]:


summer.info()


# In[ ]:


#summer.Athlete_Name


# In[ ]:


summer.rename(columns = {"Athlete Name": "Athlete_Name"}, inplace = True)


# In[ ]:


summer.head(20)


# In[ ]:


summer.Medal.value_counts()


# In[ ]:


summer.Medal.replace(to_replace= "Gold Medal", value = "Gold", inplace = True)


# In[ ]:


summer.describe(include = "O")


# ### String Operations

# #### Titanic Dataset

# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


#pd.to_numeric(titanic.Fare)


# In[ ]:


titanic.Fare = titanic.Fare.str.replace("$", "")


# In[ ]:


titanic.Fare.head()


# #### Olympic Dataset

# In[ ]:


summer.head(20)


# In[ ]:


summer.info()


# In[ ]:


summer.Athlete_Name = summer.Athlete_Name.str.title()


# In[ ]:


summer.head(10)


# In[ ]:


summer.loc[summer.Athlete_Name.str.contains("Hajos")]


# In[ ]:


summer.iloc[0, 4]


# In[ ]:


summer.Athlete_Name = summer.Athlete_Name.str.strip()


# In[ ]:


summer.loc[summer.Athlete_Name == "Hajos, Alfred"]


# In[ ]:


summer.loc[summer.Athlete_Name == "Phelps, Michael"]


# In[ ]:





# ### Changing DataType with astype() / pd.to_numeric

# #### Titanic Dataset

# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


pd.to_numeric(titanic.Fare)


# In[ ]:


titanic.Fare.astype("float")


# In[ ]:


titanic["Fare"] = titanic.Fare.astype("float")


# In[ ]:


titanic["Survived"] = titanic.Survived.astype("int")


# In[ ]:


#titanic["Age"] = titanic.Age.astype("float")


# In[ ]:


titanic.info()


# In[ ]:


titanic.head()


# #### Olympic Dataset

# In[ ]:


summer.head()


# In[ ]:


summer.info()


# In[ ]:





# ### Intro to NA Values

# In[ ]:


import numpy as np


# In[ ]:


sales = pd.read_csv("sales.csv", index_col = 0)


# In[ ]:


sales


# In[ ]:


sales.info()


# In[ ]:


sales.loc["Steven", "Thu"]


# In[ ]:


sales.iloc[1,1] = None


# In[ ]:


sales


# In[ ]:


sales.iloc[2,2] = np.nan


# In[ ]:


sales


# In[ ]:


sales.info()


# In[ ]:





# #### Titanic Dataset

# In[ ]:


titanic.head(10)


# In[ ]:


titanic.tail(10)


# In[ ]:


titanic.info()


# In[ ]:


titanic.isna()


# In[ ]:


titanic.isna().sum(axis = 0)


# In[ ]:


titanic.isna().any(axis = 1)


# In[ ]:


titanic[titanic.isna().any(axis = 1)]


# In[ ]:


titanic.notna()


# In[ ]:


titanic.notna().sum(axis = 1)


# In[ ]:


titanic.notna().all(axis = 0)


# In[ ]:


import matplotlib.pyplot as plt
import seaborn as sns


# In[ ]:


plt.figure(figsize = (12,8))
sns.heatmap(titanic.notna())
plt.show()


# In[ ]:


titanic.Age.value_counts(dropna = False)


# In[ ]:


titanic.Age.replace(to_replace= "Missing Data", value = np.nan, inplace= True)


# In[ ]:


titanic.info()


# In[ ]:


titanic.Age = titanic.Age.astype("float")


# #### Olympic Dataset

# In[ ]:


summer.head()


# In[ ]:


summer.info()


# In[ ]:


summer[summer.isna().any(axis = 1)]


# In[ ]:





# ### Removing Missing Values with dropna()

# #### Titanic Dataset

# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


titanic[titanic.Emb.isna()]


# In[ ]:


titanic.Age.value_counts(dropna = False)


# In[ ]:


titanic.Age.mean(skipna = True)


# In[ ]:


titanic.shape


# In[ ]:


titanic.dropna().shape


# In[ ]:


titanic.dropna(axis = 0, how = "any").shape


# In[ ]:


titanic.dropna(axis = 1, how = "any").shape


# In[ ]:


titanic.dropna(axis = 0, how = "all").shape


# In[ ]:


titanic.dropna(axis = 1, how = "all").shape


# In[ ]:


titanic.dropna(axis = 0, thresh = 8).shape


# In[ ]:


titanic.dropna(axis = 1, thresh = 500).shape


# In[ ]:


titanic.dropna(axis = 1, thresh = 500, inplace = True)


# In[ ]:


titanic.head()


# In[ ]:


titanic.shape


# In[ ]:


titanic.dropna(axis = 0, subset = ["Survived", "Class", "Gender", "Age"], how = "any").shape


# In[ ]:





# #### Olympic Dataset

# In[ ]:


summer.head()


# In[ ]:


summer.info()


# In[ ]:


summer[summer.isna().any(axis = 1)]


# In[ ]:


summer.dropna(inplace = True)


# In[ ]:


summer.info()


# In[ ]:





# ### Replacing Missing Values with fillna()

# #### Titanic Dataset

# In[ ]:


titanic.head(10)


# In[ ]:


titanic.info()


# In[ ]:


titanic.Age.mean()


# In[ ]:


mean = round(titanic.Age.mean(),1)
mean


# In[ ]:


titanic.Age.fillna(mean, inplace = True)


# In[ ]:


titanic.head(6)


# In[ ]:


titanic.info()


# In[ ]:





# ### Detection of Duplicates

# In[ ]:


alphabet = pd.DataFrame(["a", "b", "c", "c", "d", "e", "f", "g", "g", "g"], columns = ["Alphabet"])


# In[ ]:


alphabet


# In[ ]:


alphabet.duplicated(keep = "first")


# In[ ]:


alphabet[alphabet.duplicated(keep = "first")]


# #### Titanic Dataset

# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


titanic.duplicated(keep = "first", subset = ["Survived", "Class"]).sum()


# In[ ]:


titanic[titanic.duplicated(keep = False)]


# #### Olypmic Dataset

# In[ ]:


summer.head()


# In[ ]:


summer.info()


# In[ ]:


summer.duplicated(keep = "first").sum()


# In[ ]:


summer[summer.duplicated(keep = False)]


# In[ ]:


summer.loc[(summer.Sport == "Basketball") & (summer.Year == 2012)]


# In[ ]:





# ### Handling / Removing Duplicates

# #### Titanic Dataset

# In[ ]:


titanic.tail()


# In[ ]:


titanic.duplicated().sum()


# In[ ]:


titanic[titanic.duplicated()]


# In[ ]:


titanic.drop(index = [891, 892, 893], inplace = True)


# In[ ]:


titanic.head()


# In[ ]:


titanic.tail()


# In[ ]:


titanic.info()


# In[ ]:





# #### Olympic Dataset

# In[ ]:


summer.head()


# In[ ]:


summer[summer.duplicated(keep = False)]


# In[ ]:


summer.drop(index = [2069, 12253, 15596, 21833, 28678], inplace = True)


# In[ ]:


summer[summer.duplicated(keep = False)]


# In[ ]:


summer.loc[16085:16110]


# In[ ]:


summer.loc[29780:29795]


# In[ ]:


alphabet[alphabet.duplicated(keep = False)]


# In[ ]:


alphabet.drop_duplicates(inplace = True)


# In[ ]:


alphabet


# In[ ]:





# ### The ignore_index parameter (NEW in Pandas 1.0)

# In[ ]:


import pandas as pd


# In[ ]:


alphabet = pd.DataFrame(["a", "b", "c", "c", "d", "e", "f", "g", "g", "g"], columns = ["Alphabet"])


# In[ ]:


alphabet


# In[ ]:


alphabet.drop_duplicates(ignore_index = True).info()


# In[ ]:





# ### Detection of Outliers

# In[ ]:


titanic.head()


# In[ ]:


titanic.describe()


# In[ ]:


plt.figure(figsize = (12,6))
titanic.boxplot("Age")
plt.show()


# In[ ]:


plt.figure(figsize = (12,6))
titanic.Age.plot()
plt.show()


# In[ ]:


titanic.Age.sort_values(ascending = False)


# In[ ]:


titanic.loc[titanic.Age > 90]


# In[ ]:


titanic.Fare.sort_values(ascending = False)


# In[ ]:


plt.figure(figsize = (12,6))
titanic.Fare.plot()
plt.show()


# In[ ]:





# ### Handling / Removing Outliers

# #### Titanic Dataset

# In[ ]:


titanic.head()


# In[ ]:


titanic.loc[titanic.Age > 90]


# In[ ]:


index_outl  = titanic.loc[titanic.Age > 90].index


# In[ ]:


index_outl


# In[ ]:


titanic.loc[titanic.Age > 90, "Age"] = titanic.loc[titanic.Age > 90, "Age"]/10


# In[ ]:


titanic.loc[index_outl]


# In[ ]:


titanic.loc[217, "Age"] = 42.0


# In[ ]:


plt.figure(figsize = (12,6))
titanic.Age.plot()
plt.show()


# In[ ]:


titanic.info()


# In[ ]:





# ### Categorical Data

# #### Titanic Dataset

# In[ ]:


titanic.head()


# In[ ]:


titanic.info()


# In[ ]:


#titanic.to_csv("titanic_clean.csv", index = False)


# In[ ]:


titanic.nunique()


# In[ ]:


titanic[["Gender", "Emb"]].describe()


# In[ ]:


titanic.Gender = titanic.Gender.astype("category")


# In[ ]:


titanic.Emb = titanic.Emb.astype("category")


# In[ ]:


titanic.info()


# In[ ]:


titanic.Gender.dtype


# #### Olympic Dataset

# In[ ]:


summer.head()


# In[ ]:


summer.info()


# In[ ]:


#summer.to_csv("summer_clean.csv", index = False)


# In[ ]:


summer.describe(include = ["O"])


# In[ ]:


summer.nunique()


# In[ ]:


summer.City = summer.City.astype("category")


# In[ ]:


summer.Sport = summer.Sport.astype("category")


# In[ ]:


summer.Discipline = summer.Discipline.astype("category")


# In[ ]:


summer.Country = summer.Country.astype("category")


# In[ ]:


summer.Gender = summer.Gender.astype("category")


# In[ ]:


summer.Medal = summer.Medal.astype("category")


# In[ ]:


summer.info()


# In[ ]:





# ### Pandas Version 1.0: NEW Dtypes and pd.NA 

# In[1]:


import pandas as pd


# In[2]:


titanic = pd.read_csv("titanic.csv")


# In[3]:


titanic


# In[4]:


titanic.info()


# In[5]:


titanic = titanic.convert_dtypes()


# In[6]:


titanic.info()


# In[7]:


titanic


# In[8]:


titanic.iloc[0, -1]


# In[9]:


type(titanic.iloc[0, -1])


# In[ ]:


pd.NA


# For more information, __see Section 21__: WHAT´S NEW IN PANDAS VERSION 1.0? - A HANDS-ON GUIDE

# In[ ]:




