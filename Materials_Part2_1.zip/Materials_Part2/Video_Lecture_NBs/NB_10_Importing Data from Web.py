#!/usr/bin/env python
# coding: utf-8

# # Part 2: Full Data Workflow A-Z

# ## Importing Data from the Web  with pd.read_html()

# In[ ]:


import pandas as pd


# In[ ]:


url = "https://en.wikipedia.org/wiki/1976_Summer_Olympics_medal_table"


# In[ ]:


pd.read_html(url)[1]


# In[ ]:


wik_1976 = pd.read_html(url)[0]


# In[ ]:


wik_1976.head()


# In[ ]:


wik_1976.tail()


# In[ ]:


wik_1976.info()


# In[ ]:


url2 ="https://en.wikipedia.org/wiki/1996_Summer_Olympics_medal_table"


# In[ ]:


pd.read_html(url2)[1]


# In[ ]:


wik_1996 = pd.read_html(url2)[1]


# In[ ]:


wik_1996.head()


# In[ ]:


wik_1996.info()


# In[ ]:


wik_1976.to_csv("wik_1976.csv", index= False)
wik_1996.to_csv("wik_1996.csv", index= False)


# In[ ]:




